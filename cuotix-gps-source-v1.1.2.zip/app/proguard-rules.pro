# CUOTIX collector app. No custom rules are required in v1.0.0.
