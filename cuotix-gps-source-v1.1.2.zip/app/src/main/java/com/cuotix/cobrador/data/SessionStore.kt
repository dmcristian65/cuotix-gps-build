package com.cuotix.cobrador.data

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

class SessionStore(context: Context) {
    private val appContext = context.applicationContext
    private val masterKey = MasterKey.Builder(appContext)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()
    private val prefs = EncryptedSharedPreferences.create(
        appContext,
        "cuotix_secure_session",
        masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )
    private val runtime = appContext.getSharedPreferences("cuotix_runtime", Context.MODE_PRIVATE)

    var token: String?
        get() = prefs.getString("token", null)
        set(value) = prefs.edit().putString("token", value).apply()

    var deviceId: String?
        get() = prefs.getString("device_id", null)
        set(value) = prefs.edit().putString("device_id", value).apply()

    var collectorName: String?
        get() = prefs.getString("collector_name", null)
        set(value) = prefs.edit().putString("collector_name", value).apply()

    var trackingActive: Boolean
        get() = runtime.getBoolean("tracking_active", false)
        set(value) = runtime.edit().putBoolean("tracking_active", value).apply()

    fun clearSession() {
        prefs.edit().clear().apply()
        trackingActive = false
    }
}
