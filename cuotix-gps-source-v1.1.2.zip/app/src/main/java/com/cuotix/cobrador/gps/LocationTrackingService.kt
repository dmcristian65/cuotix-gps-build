package com.cuotix.cobrador.gps

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.net.Uri
import android.content.pm.PackageManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.cuotix.cobrador.R
import com.cuotix.cobrador.api.ApiClient
import com.cuotix.cobrador.data.LocationQueue
import com.cuotix.cobrador.data.SessionStore
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.cancel
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class LocationTrackingService : Service() {
    companion object {
        const val ACTION_START = "com.cuotix.cobrador.START_TRACKING"
        const val ACTION_STOP_AFTER_FINISH = "com.cuotix.cobrador.STOP_TRACKING_AFTER_FINISH"
        const val ACTION_STATUS = "com.cuotix.cobrador.GPS_STATUS"
        private const val CHANNEL_ID = "cuotix_route_tracking"
        private const val NOTIFICATION_ID = 11586
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private lateinit var fused: FusedLocationProviderClient
    private lateinit var store: SessionStore
    private lateinit var queue: LocationQueue
    private var callback: LocationCallback? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var uploadJob: Job? = null
    private var retryJob: Job? = null

    override fun onCreate() {
        super.onCreate()
        fused = LocationServices.getFusedLocationProviderClient(this)
        store = SessionStore(this)
        queue = LocationQueue(this)
        createChannel()
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Cuotix::RouteTracking").apply {
            setReferenceCounted(false)
            acquire()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP_AFTER_FINISH -> stopTrackingAfterFinish()
            else -> {
                if (!store.trackingActive || store.token.isNullOrBlank()) {
                    stopSelf()
                    return START_NOT_STICKY
                }
                startForeground(NOTIFICATION_ID, buildNotification("Iniciando GPS…"))
                startLocationUpdates()
            }
        }
        return START_STICKY
    }

    private fun startLocationUpdates() {
        if (callback != null) return
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            broadcastStatus("Permiso de ubicación pendiente", false)
            updateNotification("Esperando permiso de ubicación")
            return
        }
        val request = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 5_000L)
            .setMinUpdateIntervalMillis(3_000L)
            .setMaxUpdateDelayMillis(5_000L)
            .setWaitForAccurateLocation(false)
            .build()
        callback = object : LocationCallback() {
            override fun onLocationResult(result: LocationResult) {
                val location = result.lastLocation ?: return
                val point = JSONObject()
                    .put("lat", location.latitude)
                    .put("lng", location.longitude)
                    .put("accuracy", location.accuracy.toDouble())
                    .put("speed", location.speed.toDouble())
                    .put("heading", location.bearing.toDouble())
                    .put("timestamp", location.time)
                queue.add(point)
                broadcastStatus("GPS activo · precisión ${location.accuracy.toInt()} m", true)
                val time = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
                updateNotification("Ubicación enviada $time · precisión ${location.accuracy.toInt()} m")
                flushQueue()
            }
        }
        fused.requestLocationUpdates(request, callback!!, mainLooper)
        startRetryLoop()
        broadcastStatus("Buscando señal GPS…", true)
    }


    private fun startRetryLoop() {
        if (retryJob?.isActive == true) return
        retryJob = scope.launch {
            var statusTicks = 0
            while (isActive && store.trackingActive) {
                flushQueue()
                statusTicks++
                if (statusTicks >= 2) {
                    statusTicks = 0
                    val token = store.token
                    if (!token.isNullOrBlank()) {
                        val result = ApiClient.today(token)
                        val trackingRequired = result.ok && result.json.optJSONObject("run")?.optBoolean("tracking_required", false) == true
                        if (result.ok && !trackingRequired) {
                            store.trackingActive = false
                            stopTrackingAfterFinish()
                            break
                        }
                    }
                }
                delay(15_000L)
            }
        }
    }

    private fun flushQueue() {
        if (uploadJob?.isActive == true) return
        val token = store.token ?: return
        val points = queue.all()
        if (points.isEmpty()) return
        uploadJob = scope.launch {
            val result = ApiClient.locations(token, points)
            if (result.ok) {
                queue.clear()
            } else {
                broadcastStatus("Sin conexión · guardando recorrido", true)
                updateNotification("Sin conexión. El recorrido se guardó para sincronizar.")
            }
        }
    }

    private fun stopTrackingAfterFinish() {
        store.trackingActive = false
        callback?.let { fused.removeLocationUpdates(it) }
        callback = null
        retryJob?.cancel(); retryJob = null
        queue.clear()
        broadcastStatus("Recorrido finalizado · GPS detenido", false)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun broadcastStatus(message: String, active: Boolean) {
        sendBroadcast(Intent(ACTION_STATUS).setPackage(packageName).putExtra("message", message).putExtra("active", active))
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, getString(R.string.tracking_channel), NotificationManager.IMPORTANCE_LOW).apply {
                description = getString(R.string.tracking_notification_text)
                setShowBadge(false)
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String): android.app.Notification {
        val panelIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://cuotix.net/cobrador/?section=cobranzas-dia"))
        val panelPending = PendingIntent.getActivity(
            this,
            11587,
            panelIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_cuotix_app)
            .setContentTitle(getString(R.string.tracking_notification_title))
            .setContentText(text)
            .setContentIntent(panelPending)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()
    }

    private fun updateNotification(text: String) {
        if (Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
            NotificationManagerCompat.from(this).notify(NOTIFICATION_ID, buildNotification(text))
        }
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        super.onTaskRemoved(rootIntent)
        if (store.trackingActive) scheduleRestart(2_000L)
    }

    override fun onDestroy() {
        callback?.let { fused.removeLocationUpdates(it) }
        callback = null
        if (store.trackingActive) scheduleRestart(5_000L)
        wakeLock?.let { if (it.isHeld) it.release() }
        scope.cancel()
        super.onDestroy()
    }

    private fun scheduleRestart(delay: Long) {
        val intent = Intent(this, TrackingRestartReceiver::class.java).setAction("com.cuotix.cobrador.RESTART_TRACKING")
        val pending = PendingIntent.getBroadcast(this, 11586, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val alarm = getSystemService(ALARM_SERVICE) as AlarmManager
        alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + delay, pending)
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
