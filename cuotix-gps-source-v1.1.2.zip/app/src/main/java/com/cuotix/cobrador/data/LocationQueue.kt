package com.cuotix.cobrador.data

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import org.json.JSONArray
import org.json.JSONObject

class LocationQueue(context: Context) {
    private val appContext = context.applicationContext
    private val masterKey = MasterKey.Builder(appContext)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()
    private val prefs = EncryptedSharedPreferences.create(
        appContext,
        "cuotix_location_queue",
        masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    @Synchronized
    fun add(point: JSONObject) {
        val list = readMutable()
        list.add(point)
        while (list.size > 500) list.removeAt(0)
        write(list)
    }

    @Synchronized
    fun all(): List<JSONObject> = readMutable().toList()

    @Synchronized
    fun clear() = prefs.edit().remove("points").apply()

    private fun readMutable(): MutableList<JSONObject> {
        val raw = prefs.getString("points", "[]") ?: "[]"
        return try {
            val array = JSONArray(raw)
            MutableList(array.length()) { i -> array.getJSONObject(i) }
        } catch (_: Exception) { mutableListOf() }
    }

    private fun write(points: List<JSONObject>) {
        val array = JSONArray()
        points.forEach { array.put(it) }
        prefs.edit().putString("points", array.toString()).apply()
    }
}
