package com.cuotix.cobrador.ui

import android.Manifest
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.cuotix.cobrador.api.ApiClient
import com.cuotix.cobrador.data.SessionStore
import com.cuotix.cobrador.gps.LocationTrackingService
import kotlinx.coroutines.launch

/**
 * Invisible bridge between the CUOTIX web panel and the native GPS service.
 * This activity has no launcher icon and is only opened by cuotixgps:// links.
 */
class BridgeActivity : AppCompatActivity() {
    private lateinit var store: SessionStore
    private var command: String = ""
    private var bridgeCode: String = ""
    private var returnUrl: String = "https://cuotix.net/cobrador/?section=cobranzas-dia"
    private var exchangeCompleted = false
    private var waitingForSettings = false
    private var batteryPrompted = false
    private var commandRunning = false

    private val locationPermissions = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        if (result[Manifest.permission.ACCESS_FINE_LOCATION] == true) {
            continuePermissionFlow()
        } else {
            fail("Necesitás permitir la ubicación precisa para utilizar el seguimiento del recorrido.")
        }
    }

    private val backgroundPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) requestBatteryAccessThenRun()
        else fail("Necesitás permitir la ubicación todo el tiempo para registrar el recorrido con el panel cerrado.")
    }

    private val notificationsPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { requestBatteryAccessThenRun() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = SessionStore(this)
        readIntent(intent)
        if (command.isBlank() || bridgeCode.isBlank()) {
            fail("El enlace del complemento GPS no es válido. Volvé al panel CUOTIX e intentá nuevamente.")
            return
        }
        exchangeBridgeCode()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        readIntent(intent)
        exchangeCompleted = false
        commandRunning = false
        exchangeBridgeCode()
    }

    override fun onResume() {
        super.onResume()
        if (waitingForSettings && exchangeCompleted) {
            waitingForSettings = false
            if (hasFineLocation() && hasBackgroundLocation()) requestBatteryAccessThenRun()
            else continuePermissionFlow()
        }
    }

    private fun readIntent(source: Intent?) {
        val uri = source?.data
        command = uri?.getQueryParameter("action").orEmpty()
        bridgeCode = uri?.getQueryParameter("code").orEmpty()
        returnUrl = uri?.getQueryParameter("return_url")
            ?.takeIf { it.startsWith("https://cuotix.net/") }
            ?: "https://cuotix.net/cobrador/?section=cobranzas-dia"
    }

    private fun exchangeBridgeCode() {
        val deviceId = Settings.Secure.getString(contentResolver, Settings.Secure.ANDROID_ID)
            ?: "android-device"
        val deviceName = "${Build.MANUFACTURER} ${Build.MODEL}"
        lifecycleScope.launch {
            val result = ApiClient.bridgeExchange(bridgeCode, deviceId, deviceName)
            if (!result.ok) {
                fail(result.message("No se pudo vincular el complemento GPS con CUOTIX."))
                return@launch
            }
            command = result.json.optString("action", command)
            store.token = result.json.optString("token")
            store.deviceId = result.json.optString("device_id", deviceId)
            store.collectorName = result.json.optJSONObject("collector")?.optString("name")
            result.json.optString("return_url").takeIf { it.startsWith("https://cuotix.net/") }?.let {
                returnUrl = it
            }
            exchangeCompleted = true
            when (command) {
                "finish_route" -> executeCommand()
                "start_day", "start_route", "prepare" -> ensurePermissions()
                else -> fail("La acción solicitada por CUOTIX no es válida.")
            }
        }
    }

    private fun ensurePermissions() {
        if (!hasFineLocation()) {
            locationPermissions.launch(
                arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                )
            )
            return
        }
        continuePermissionFlow()
    }

    private fun continuePermissionFlow() {
        if (Build.VERSION.SDK_INT == 29 && !hasBackgroundLocation()) {
            backgroundPermission.launch(Manifest.permission.ACCESS_BACKGROUND_LOCATION)
            return
        }
        if (Build.VERSION.SDK_INT >= 30 && !hasBackgroundLocation()) {
            AlertDialog.Builder(this)
                .setTitle("Permitir ubicación todo el tiempo")
                .setMessage("Para que el GPS continúe aunque cierres el panel o bloquees el teléfono, elegí Ubicación y luego Permitir todo el tiempo.")
                .setCancelable(false)
                .setNegativeButton("Cancelar") { _, _ -> returnToPanel() }
                .setPositiveButton("Abrir configuración") { _, _ ->
                    waitingForSettings = true
                    startActivity(
                        Intent(
                            Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                            Uri.parse("package:$packageName")
                        )
                    )
                }
                .show()
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notificationsPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
            return
        }
        requestBatteryAccessThenRun()
    }

    private fun requestBatteryAccessThenRun() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            if (!pm.isIgnoringBatteryOptimizations(packageName) && !batteryPrompted) {
                try {
                    batteryPrompted = true
                    waitingForSettings = true
                    startActivity(
                        Intent(
                            Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                            Uri.parse("package:$packageName")
                        )
                    )
                    return
                } catch (_: Exception) {
                    // Some vendors do not expose the direct screen. Tracking still works
                    // through the foreground service and its permanent notification.
                }
            }
        }
        executeCommand()
    }

    private fun executeCommand() {
        if (commandRunning) return
        commandRunning = true
        val token = store.token
        if (token.isNullOrBlank()) {
            fail("No se pudo guardar la sesión del complemento GPS.")
            return
        }
        lifecycleScope.launch {
            if (command != "finish_route") {
                val ready = ApiClient.companionReady(token, store.deviceId.orEmpty())
                if (!ready.ok) {
                    fail(ready.message("No se pudo verificar la instalación del complemento GPS."))
                    return@launch
                }
            }
            when (command) {
                "prepare" -> {
                    // La vinculación ya informó la versión instalada al servidor.
                    // Verificar el complemento no debe iniciar la jornada.
                    returnToPanel()
                }
                "start_day" -> {
                    val result = ApiClient.journey(token, "start_day")
                    if (!result.ok) {
                        fail(result.message("No se pudo comenzar el día de trabajo."))
                        return@launch
                    }
                    returnToPanel()
                }
                "start_route" -> {
                    val result = ApiClient.journey(token, "start_route")
                    if (!result.ok) {
                        fail(result.message("No se pudo comenzar el recorrido."))
                        return@launch
                    }
                    store.trackingActive = true
                    ContextCompat.startForegroundService(
                        this@BridgeActivity,
                        Intent(this@BridgeActivity, LocationTrackingService::class.java)
                            .setAction(LocationTrackingService.ACTION_START)
                    )
                    returnToPanel()
                }
                "finish_route" -> {
                    val result = ApiClient.journey(token, "finish_route")
                    if (!result.ok && result.code != 409) {
                        fail(result.message("No se pudo finalizar el recorrido."))
                        return@launch
                    }
                    store.trackingActive = false
                    startService(
                        Intent(this@BridgeActivity, LocationTrackingService::class.java)
                            .setAction(LocationTrackingService.ACTION_STOP_AFTER_FINISH)
                    )
                    returnToPanel()
                }
            }
        }
    }

    private fun returnToPanel() {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(returnUrl)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) {
            // The browser can always be opened manually if Android has no default handler.
        }
        finishAndRemoveTask()
    }

    private fun fail(message: String) {
        if (isFinishing) return
        AlertDialog.Builder(this)
            .setTitle("CUOTIX GPS")
            .setMessage(message)
            .setCancelable(false)
            .setPositiveButton("Volver al panel") { _, _ -> returnToPanel() }
            .show()
    }

    private fun hasFineLocation(): Boolean =
        ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun hasBackgroundLocation(): Boolean =
        Build.VERSION.SDK_INT < 29 ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_BACKGROUND_LOCATION) == PackageManager.PERMISSION_GRANTED
}
