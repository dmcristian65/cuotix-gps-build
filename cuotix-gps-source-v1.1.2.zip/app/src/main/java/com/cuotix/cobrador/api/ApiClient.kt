package com.cuotix.cobrador.api

import com.cuotix.cobrador.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object ApiClient {
    private val jsonType = "application/json; charset=utf-8".toMediaType()
    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .writeTimeout(25, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()
    private val apiBase = BuildConfig.CUOTIX_BASE_URL.trimEnd('/') + "/wp-json/cuotix-mobile/v1"

    data class Result(val code: Int, val json: JSONObject) {
        val ok: Boolean get() = code in 200..299
        fun message(default: String): String = json.optString("message", json.optString("code", default))
    }

    suspend fun bridgeExchange(code: String, deviceId: String, deviceName: String): Result = post(
        "/bridge/exchange",
        JSONObject().put("code", code).put("device_id", deviceId).put("device_name", deviceName)
            .put("app_version", BuildConfig.VERSION_NAME).put("app_version_code", BuildConfig.VERSION_CODE),
        null
    )

    suspend fun companionReady(token: String, deviceId: String): Result = post(
        "/bridge/ready",
        JSONObject().put("device_id", deviceId)
            .put("app_version", BuildConfig.VERSION_NAME)
            .put("app_version_code", BuildConfig.VERSION_CODE),
        token
    )
    suspend fun session(token: String): Result = get("/session", token)
    suspend fun today(token: String): Result = get("/today", token)
    suspend fun journey(token: String, action: String): Result = post("/journey", JSONObject().put("action", action), token)
    suspend fun webLink(token: String): Result = post("/web-link", JSONObject(), token)
    suspend fun logout(token: String, deviceId: String): Result = post("/logout", JSONObject().put("device_id", deviceId), token)
    suspend fun locations(token: String, points: List<JSONObject>): Result {
        val array = JSONArray(); points.forEach { array.put(it) }
        return post("/location", JSONObject().put("points", array), token)
    }

    private suspend fun get(path: String, token: String): Result = withContext(Dispatchers.IO) {
        execute(Request.Builder().url(apiBase + path).get().header("Authorization", "Bearer $token").header("Cache-Control", "no-cache").build())
    }

    private suspend fun post(path: String, body: JSONObject, token: String?): Result = withContext(Dispatchers.IO) {
        val builder = Request.Builder().url(apiBase + path).post(body.toString().toRequestBody(jsonType))
        if (!token.isNullOrBlank()) builder.header("Authorization", "Bearer $token")
        execute(builder.build())
    }

    private fun execute(request: Request): Result {
        return try {
            client.newCall(request).execute().use { response ->
                val raw = response.body?.string().orEmpty()
                val json = try { if (raw.isBlank()) JSONObject() else JSONObject(raw) } catch (_: Exception) { JSONObject().put("message", raw) }
                Result(response.code, json)
            }
        } catch (e: Exception) {
            Result(0, JSONObject().put("message", e.message ?: "Sin conexión"))
        }
    }
}
