package com.cuotix.cobrador.gps

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import com.cuotix.cobrador.data.SessionStore

class TrackingRestartReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val store = SessionStore(context)
        if (!store.trackingActive || store.token.isNullOrBlank()) return
        val serviceIntent = Intent(context, LocationTrackingService::class.java).setAction(LocationTrackingService.ACTION_START)
        ContextCompat.startForegroundService(context, serviceIntent)
    }
}
